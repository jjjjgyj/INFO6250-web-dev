const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();
const PORT = process.env.PORT || 3000;

const sessions = require('./sessions');
const users = require('./users');

app.use(cookieParser());
app.use(express.static('./build'));
app.use(express.json());

// Sessions
app.get('/api/session', (req, res) => {
  const sid = req.cookies.sid;
  const username = sid ? sessions.getSessionUser(sid) : '';
  if(!sid || !users.isValid(username)) {
    res.status(401).json({ error: 'auth-missing' });
    return;
  }

  res.json({ username });
});

app.post('/api/session', (req, res) => {
  const { username } = req.body;

  if(!users.isValid(username)) {
    res.status(400).json({ error: 'required-username' });
    return;
  }

  if(username === 'dog') {
    res.status(403).json({ error: 'auth-insufficient' });
    return;
  }

  if (!users.profileFor[username]) {
    users.addUser(username);
  }

  const userProfile = users.profileFor[username];
  const sid = sessions.addSession(username);

  res.cookie('sid', sid);
  res.json({username, userProfile});    
});

app.delete('/api/session', (req, res) => {
  const sid = req.cookies.sid;
  const username = sid ? sessions.getSessionUser(sid) : '';

  if(sid) {
    res.clearCookie('sid');
  }

  if(username) {
    sessions.deleteSession(sid);
  }

  res.json({ username });
});

// Game
app.get('/api/profile', (req, res) => {
  const sid = req.cookies.sid;
  const username = sid ? sessions.getSessionUser(sid) : '';

  if(!sid || !username) {
    res.status(401).json({ error: 'auth-missing' });
    return;
  }

  if (!users.profileFor[username].playerCard) {
    users.givePlayerCard(username);
  }
  
  const userProfile = users.profileFor[username];
  
  res.json({ username, userProfile });
});

app.get('/api/newgame', (req, res) => {
  const sid = req.cookies.sid;
  const username = sid ? sessions.getSessionUser(sid) : '';

  if(!sid || !username) {
    res.status(401).json({ error: 'auth-missing' });
    return;
  }
  
  users.startNewGame(username);
  const userProfile = users.profileFor[username];
  res.json({ username, userProfile });
});

app.put('/api/game', (req, res) => {
  const sid = req.cookies.sid;
  const username = sid ? sessions.getSessionUser(sid) : '';
  if(!sid || !username) {
    res.status(401).json({ error: 'auth-missing' });
    return;
  }

  const { dealerCard, playerCard, betAmount } = req.body;

  if( betAmount && !users.isValidBet(betAmount)) {
    res.status(400).json({ error: 'invalid-bet' });
    return;
  }

  users.playGame(username, dealerCard, playerCard, betAmount);
  const userProfile = users.profileFor[username];

  res.json({ username, userProfile });
});

app.listen(PORT, () => console.log(`Listening on http://localhost:${PORT}`));
