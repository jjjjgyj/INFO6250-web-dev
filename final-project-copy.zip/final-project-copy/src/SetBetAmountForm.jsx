import { useState } from 'react';
function SetBetAmountForm({ dispatch, betAmount, onPlaceBet }) {

  const [ bet, setBet ] = useState('');
  
  function onSubmit(e) {
    e.preventDefault(); 
    if (!betAmount && bet.match(/^[0-9]+$/)){
      onPlaceBet(dispatch, parseInt(bet)); 
      setBet('');
    }
  }

  function onTyping(e) {
    setBet(e.target.value);
  }

  return (
      <div>
          <form className="update-form" action="#/update" onSubmit={onSubmit}>
            <input className="update-bet" value={bet} onChange={onTyping} placeholder="Enter your bet amount"/>
            <button type="submit" className="update-button-bet">Confirm</button>
          </form>
      </div>
    );    
}

export default SetBetAmountForm;
