import { useEffect, useReducer } from 'react';
import { 
  onLogin,
  onLogout,
  onPlayGame,
  onStartNewGame,
  onShowStats,
  onPlaceBet,
  checkForSession,
} from './handlers';
import './App.css';
import { LOGIN_STATUS } from './constants';
import LoginForm from './LoginForm';
import Loading from './Loading';
import Controls from './Controls';
import Status from './Status';
import SetBetAmountForm from './SetBetAmountForm';
import GameContent from './GameContent';
import PlayGameForm from './PlayGameForm';
import Stats from './Stats';
import reducer, { initialState } from './reducer';

function App() {

  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(
    () => { checkForSession(dispatch); },
    []
  );

  return (
    <div className="app">
      <main className="">
        { state.error && <Status error={state.error}/> }
        { state.loginStatus === LOGIN_STATUS.PENDING && <Loading className="login-waiting">Loading user...</Loading> }
        { state.loginStatus === LOGIN_STATUS.NOT_LOGGED_IN && <LoginForm dispatch={dispatch} onLogin={onLogin} /> }
        { state.loginStatus === LOGIN_STATUS.IS_LOGGED_IN && (
          <div className="content">
            <p className="content-intro">Good Luck Winning, {state.username}!</p>
            <Controls 
              dispatch={dispatch}
              state={state}
              onLogout={onLogout} 
              onStartNewGame={onStartNewGame}
              onShowStats={onShowStats}
              isStatsHidden={state.isStatsHidden}/>
            <div className="game-content-outter">
              <div className="game-content-nonstat">
                <GameContent 
                  playerCard={state.playerCard} 
                  dealerCard={state.dealerCard}
                  betAmount={state.betAmount} 
                  balance={state.balance} 
                  setBalance={state.setBalance}
                  isPlayingGame={state.isPlayingGame}
                  isProfilePending={state.isProfilePending}/>
                <SetBetAmountForm 
                  dispatch={dispatch}
                  betAmount={state.betAmount} 
                  onPlaceBet={onPlaceBet}/>
                <PlayGameForm 
                  dispatch={dispatch}
                  onPlayGame={onPlayGame}
                  playerCard={state.playerCard}
                  betAmount={state.betAmount}
                  isPlayingGame={state.isPlayingGame}/>
              </div>
              <Stats 
                wins={state.wins} 
                losses={state.losses} 
                isStatsHidden={state.isStatsHidden}/>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
