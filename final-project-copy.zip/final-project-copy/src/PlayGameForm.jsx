function PlayGameForm({ dispatch, onPlayGame, playerCard, betAmount, isPlayingGame}) {

  let randomDealerCard = (playerCard && betAmount && !isPlayingGame) ? Math.floor(Math.random() * 13) + 1 : 0; 

  function onSubmit(e) {
    e.preventDefault(); 
    
    if (playerCard && betAmount && !isPlayingGame) {
      onPlayGame(dispatch, randomDealerCard, playerCard, betAmount);
    } 
  }

  return (
      <form className="update-form" action="#/update" onSubmit={onSubmit}>
        <button type="submit" className="update-button-play">Play Game</button>
      </form>
    );    
}
  
export default PlayGameForm;
