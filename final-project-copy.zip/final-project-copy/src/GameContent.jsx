function GameContent({ playerCard, dealerCard, betAmount, balance, isPlayingGame, isProfilePending}) {
    let uniqueMessage = '';
    const generalMessage = (playerCard && dealerCard && betAmount && isPlayingGame) ? "Click 'New Game' to Try Again" : '';
    if (playerCard && dealerCard && betAmount && isPlayingGame){
        if (playerCard < dealerCard) {
            uniqueMessage = `Oh no! You are smaller and you lost $${betAmount}!`;
        } else if (playerCard > dealerCard) {
            uniqueMessage = `Congratulations! You are bigger and you won $${betAmount}!`;
        } else {
            uniqueMessage = 'You tied with the dealer! Play again!';
        }
    }

    const profile = <div>
                        <div>Dealer Card: {dealerCard}</div>
                        <div>Player Card: {playerCard}</div>
                        <div>Your Bet: ${betAmount}</div>
                        <div>Your Balance: ${balance}</div>
                        <div className="game-note">{uniqueMessage}</div>
                        <div className="newgame-note">{generalMessage}</div>
                    </div>;  

    const profildLoadingMessage =   <div>
                                        <div>Loading player profile...</div>
                                    </div>;                                    

    return (
            <div>
                <div>{isProfilePending && profildLoadingMessage}</div>
                <div>{!isProfilePending && profile}</div>
            </div>
        );    
}

export default GameContent;
