import {
    CLIENT,
    SERVER,
    ACTIONS,
} from './constants';
import {
    fetchSession,
    fetchLogin,
    fetchLogout,
    fetchUserProfile,
    fetchNewGame,
    fetchPlayGame
} from './services';

export function onLogin( dispatch, username ) {
    dispatch({ type: ACTIONS.LOGIN_PENDING });
    dispatch({ type: ACTIONS.LOADING_PROFILE });
    dispatch({ type: ACTIONS.STATS, statsHidden: true });
    fetchLogin(username)
    .then( profile => {
        const {dealerCard, playerCard, betAmount, balance, wins, losses} = profile.userProfile;
        const actualPlayerCard = (playerCard) ? playerCard : Math.floor(Math.random() * 13) + 1;
        const gameStatus = dealerCard && playerCard && betAmount;
        dispatch({ type: ACTIONS.LOG_IN, username });
        dispatch({ type: ACTIONS.UPDATE_PROFILE, dealerCard, playerCard: actualPlayerCard, betAmount, balance, wins, losses, gameStatus });
    })
    .catch( err => {
        dispatch({ type: ACTIONS.LOG_OUT });
        dispatch({ type: ACTIONS.REPORT_ERROR, error: err?.error });
    });
}

export function onLogout( dispatch ) {
    dispatch({ type: ACTIONS.LOG_OUT });
    fetchLogout()
    .catch( err => {
        dispatch({ type: ACTIONS.STATS, statsHidden: true });
        dispatch({ type: ACTIONS.REPORT_ERROR, error: err?.error });
    });
}

export function onPlayGame( dispatch, dealerCardEntered, playerCardEntered, betEntered ) {
    dispatch({ type: ACTIONS.LOADING_PROFILE });
    fetchPlayGame(dealerCardEntered, playerCardEntered, betEntered)
    .then( profile => {
        const {dealerCard, playerCard, betAmount, balance, wins, losses} = profile.userProfile;
        dispatch({ type: ACTIONS.UPDATE_PROFILE, gameStatus: true, dealerCard, playerCard, betAmount, balance, wins, losses });
    })
    .catch( err => {
        dispatch({ type: ACTIONS.STATS, statsHidden: true });
        dispatch({ type: ACTIONS.REPORT_ERROR, error: err?.error });
    });
}

export function onStartNewGame( dispatch ) {
    dispatch({ type: ACTIONS.LOADING_PROFILE });
    fetchNewGame()
    .then( profile => {
        const {dealerCard, playerCard, betAmount, balance, wins, losses} = profile.userProfile;
        dispatch({ type: ACTIONS.UPDATE_PROFILE, gameStatus: false, dealerCard, playerCard, betAmount, balance, wins, losses });
    })
    .catch( err => {
        dispatch({ type: ACTIONS.STATS, statsHidden: true });
        dispatch({ type: ACTIONS.REPORT_ERROR, error: err?.error });
    });
}

export function onShowStats( dispatch, state ) {
    dispatch({ type: ACTIONS.STATS, statsHidden: !state.isStatsHidden });
}

export function onPlaceBet( dispatch, betAmount ) {
    dispatch({ type: ACTIONS.PLACE_BET, betAmount });
}

export function checkForSession( dispatch ) {
    dispatch({ type: ACTIONS.LOGIN_PENDING });
    fetchSession()
    .then( session => { 
        dispatch({ type: ACTIONS.LOG_IN, username: session.username });
        dispatch({ type: ACTIONS.LOADING_PROFILE });
        return fetchUserProfile(); 
    })
    .catch( err => {
        if( err?.error === SERVER.AUTH_MISSING ) {
            return Promise.reject({ error: CLIENT.NO_SESSION }) 
        }
        return Promise.reject(err); 
    })
    .then( profile => {
        const {dealerCard, playerCard, betAmount, balance, wins, losses} = profile.userProfile;
        const gameStatus = dealerCard && playerCard && betAmount;
        dispatch({ type: ACTIONS.UPDATE_PROFILE, gameStatus, dealerCard, playerCard, betAmount, balance, wins, losses });
        dispatch({ type: ACTIONS.STATS, statsHidden: true });
    })
    .catch( err => {
        dispatch({ type: ACTIONS.STATS, statsHidden: true });
        if( err?.error === CLIENT.NO_SESSION ) { 
            dispatch({ type: ACTIONS.LOG_OUT });
            return;
        }
        dispatch({ type: ACTIONS.REPORT_ERROR, error: err?.error });
    });
}
