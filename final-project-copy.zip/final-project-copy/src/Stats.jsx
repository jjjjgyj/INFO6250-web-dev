function  Stats({ wins, losses, isStatsHidden }) {
    
    function formatAsPercent(num) {
        return `${parseFloat(num).toFixed(0)}%`;
    }

    const percentage = (wins + losses) ? formatAsPercent(wins / (wins + losses) * 100) : '0%';
    const stat = <div className="game-content-stat">
                    <div>Past Wins: {wins}</div>
                    <div>Past Losses: {losses}</div>
                    <div>Winning Rate: {percentage}</div>
                </div>;
    const stats = (!isStatsHidden) ? stat : <div></div>;

    return (
        <div>{stats}</div>
    );    
}

export default Stats;
