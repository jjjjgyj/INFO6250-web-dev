import {
    LOGIN_STATUS,
    CLIENT,
    ACTIONS,
  } from './constants';
  
export const initialState = {
    error: '',
    username: '',
    loginStatus: LOGIN_STATUS.PENDING,
    dealerCard: 0,
    playerCard: 0,
    betAmount: 0,
    balance: 0,
    wins: 0,
    losses: 0,
    isPlayingGame: false,
    isStatsHidden: true, 
    isProfilePending: false
};
  
function reducer(state, action) {
    switch(action.type) {
        case ACTIONS.LOGIN_PENDING:
            return {
                ...state,
                error: '',
                loginStatus: LOGIN_STATUS.PENDING,
                username: '',
            };

        case ACTIONS.LOG_IN: 
            return {
                ...state,
                error: '', 
                loginStatus: LOGIN_STATUS.IS_LOGGED_IN,
                username: action.username,
            };

        case ACTIONS.LOG_OUT:
            return {
                ...state,
                error: '',
                loginStatus: LOGIN_STATUS.NOT_LOGGED_IN,
                username: '',
                dealerCard: 0,
                playerCard: 0,
                betAmount: 0,
                balance: 0,
                wins: 0,
                losses: 0,
                isPlayingGame: false,
            };
        
        case ACTIONS.LOADING_PROFILE:
            return {
                ...state,
                isProfilePending: true,
                isPlayingGame: false,   
            };

        case ACTIONS.UPDATE_PROFILE:
            return {
                ...state,
                error: '',
                dealerCard: action.dealerCard,
                playerCard: action.playerCard,
                betAmount: action.betAmount,
                balance: action.balance,
                wins: action.wins,
                losses: action.losses,
                isPlayingGame: action.gameStatus,
                isProfilePending: false, 
            };

        case ACTIONS.PLACE_BET:
            return {
                ...state,
                betAmount: action.betAmount, 
            };

        case ACTIONS.STATS:
            return {
                ...state,
                isStatsHidden: action.statsHidden, 
            };
            
        case ACTIONS.REPORT_ERROR:
            return {
                ...state,
                error: action.error || 'ERROR', 
            };

        default:
            throw new Error({ error: CLIENT.UNKNOWN_ACTION, detail: action }); 
    }
}
  
export default reducer;
  