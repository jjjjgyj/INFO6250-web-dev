import { useState } from 'react';

function LoginForm({ onLogin, dispatch }) {
  const [username, setUsername] = useState('');

  function onChange(e) {
    setUsername(e.target.value);
  }

  function onSubmit(e) {
    e.preventDefault(); 
    if(username) {  
      onLogin(dispatch, username); 
    }
  }

  return (
      <div className="login">
        <div>
          <p className='login-welcome'>Welcome to the Casino!</p>
          <p className='login-welcome-note'>Login to play Guess Who's Bigger</p>
        </div>
        <form className="login-form" action="#/login" onSubmit={onSubmit}>
          <label>
            <input className="login-username" value={username} onChange={onChange} placeholder="Enter your username"/>
          </label>
          <button className="login-button" type="submit">Login</button>
        </form>
      </div>
    );
}

export default LoginForm;
