function Controls({ dispatch, state, onLogout, onStartNewGame, onShowStats, isStatsHidden }) {

  const buttonName = (isStatsHidden) ? 'Show Stats' : 'Hide Stats';
  
  function onLogoutLocal () {
    return onLogout(dispatch)
  }

  function onStartNewGameLocal () {
    return onStartNewGame(dispatch, state)
  }

  function onShowStatsLocal () {
    return onShowStats(dispatch, state)
  }

  return (
    <div className="controls">
      <button onClick={onLogoutLocal} className="controls-logout">Logout</button>
      <button onClick={onStartNewGameLocal} className="controls-newgame">New Game</button>
      <button onClick={onShowStatsLocal} className="controls-stats">{buttonName}</button>
    </div>
  );
}

export default Controls;
