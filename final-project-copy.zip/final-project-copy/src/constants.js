export const LOGIN_STATUS = {
  PENDING: 'pending',
  NOT_LOGGED_IN: 'notLoggedIn',
  IS_LOGGED_IN: 'loggedIn',
};

export const SERVER = {
  AUTH_MISSING: 'auth-missing',
  AUTH_INSUFFICIENT: 'auth-insufficient',
  REQUIRED_USERNAME: 'required-username',
  INVALID_BET: 'invalid-bet'
};

export const CLIENT = {
  NETWORK_ERROR: 'networkError',
  NO_SESSION: 'noSession',
};

export const MESSAGES = {
  [CLIENT.NETWORK_ERROR]: 'Trouble connecting to the network.  Please resolve and try again',
  [SERVER.AUTH_INSUFFICIENT]: 'Your username/password combination does not match any records, please correct and try again.',
  [SERVER.REQUIRED_USERNAME]: 'Please enter a valid (letters and/or numbers) username',
  [SERVER.INVALID_BET]: 'Please enter a valid bet amount that is greater than 0',
  default: 'Something went wrong.  Please resolve and try again',
};

export const ACTIONS = {
  LOG_IN: 'logIn',
  LOG_OUT: 'logOut',
  LOGIN_PENDING: 'pending',
  LOADING_PROFILE: 'loadingaProfile',
  PLACE_BET: 'placeBet',
  STATS: 'stats',
  REPORT_ERROR: 'reportError',
};
