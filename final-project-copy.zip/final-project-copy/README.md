# Casino Game - Guess Who's Bigger

## Game Description 
### Idea
* This is a casino game called "Guess Who's Bigger", a simple game played between a player and a dealer. Whoever has a bigger card wins the game. 
### Process
* Upon the start of a game, the player is handed a card randomly picked from a deck. Then the player is required to place a bet. After the player places a bet, the dealer will show his/her card that is also randomly picked from a deck. 
* If the dealer's card is greater than the player's card, the player will lose the bet amount; if the player's card is greater than the dealer's card, the player will win the bet amount; if both cards tie, the player will has no gain or loss. 
* The player's balance at the casino is updated after the player's gain or loss of the current game is determined. The player's total wins and losses are also updated. 
* The player has the option to start a new game after the current game ends. 
* The player has the option to view his/her game stats (past wins & losses and total winning rate) of the game at this casino. 
### Logistics
* This game supports multiple players to play individually at the same time. 

## Game Rules
* The player cannot continue playing a game that already ends. 
    * The casino updates the player's game stats after each individual game.
* The player cannot start a new game when a current game is not finished.
    * The casino cannot let you only play the game you can win.
* The player cannot place no bet. Bet amount must be greater than $0.
    * A game is not free. You need to pay for the chance of winning.
* A game cannot start until the player places a bet.
    * Same reason as above.


## Getting Started
* `cd` into the `final-project` folder
* Run `npm install`
* Run `npm run build`
* Run `npm start`
* Enjoy the game - GOOD LUCK WINNING! 

## Source and Licensing
* Background Image - https://images.unsplash.com/photo-1596838132731-3301c3fd4317?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8Y2FzaW5vfGVufDB8fDB8fA%3D%3D&w=1000&q=80