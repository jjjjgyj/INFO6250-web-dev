const profileFor = {
  // Example players
  'Tom':{ dealerCard: 0, playerCard: 3, betAmount: 0, balance: 0, wins: 0, losses: 0}, 
  'Hank':{ dealerCard: 1, playerCard: 2, betAmount: 0, balance: 10,  wins: 5, losses: 8} 
}

function isValid(username) {
  let isValid = true;
  isValid = !!username && username.trim();
  isValid = isValid && username.match(/^[A-Za-z0-9_]+$/);
  return isValid;
}

function isValidBet(bet) {
  let isValid = true;
  isValid = isValid && bet > 0;
  return isValid;
}

function addUser(username) {
  const pickPlayerCard = Math.floor(Math.random() * 13) + 1;
  profileFor[username] = {dealerCard: 0, playerCard: pickPlayerCard, betAmount: 0, balance: 0, wins: 0, losses: 0};
}

function startNewGame(username) {
  profileFor[username].dealerCard = 0;

  // Prevent player from restarting just to get a big card
  if (profileFor[username].betAmount) {
    profileFor[username].playerCard = Math.floor(Math.random() * 13) + 1;
  }
  
  profileFor[username].betAmount = 0;
}

function playGame(username, dealerCard, playerCard, betAmount) {
  profileFor[username].dealerCard = dealerCard;
  profileFor[username].playerCard = playerCard;
  profileFor[username].betAmount = betAmount;

  let gainOrLoss = 0; 

  if (dealerCard > playerCard) {
    gainOrLoss = -betAmount;
    profileFor[username].losses += 1;
  } else if (playerCard > dealerCard) {
    gainOrLoss = betAmount;
    profileFor[username].wins += 1; 
  }

  profileFor[username].balance += gainOrLoss;
}

function givePlayerCard(username) {
  profileFor[username].playerCard = Math.floor(Math.random() * 13) + 1;
}

module.exports = {
  isValid,  
  isValidBet,
  profileFor,
  addUser,
  startNewGame,
  playGame,
  givePlayerCard
};
 